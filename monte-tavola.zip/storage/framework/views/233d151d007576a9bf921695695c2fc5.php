<?php $__env->startSection('title', 'お問い合わせ'); ?>
<?php $__env->startSection('content'); ?>
<div class="py-20">

    
    <h1 class="text-center text-2xl font-semibold text-[#363427] mb-10 mt-20">
        入力内容のご確認
    </h1>

    
    <div class="max-w-4xl mx-auto bg-[#F1ECEB] p-12 rounded-2xl">

        
        <p class="text-center text-sm text-[#363427] leading-relaxed mb-12">
            以下の内容でよろしければ、「送信する」ボタンを押してください。<br>
            内容に誤りがある場合は、「戻る」ボタンでご確認ください。
        </p>

        
        <div class="space-y-10 mb-10 text-[#363427] max-w-2xl mx-auto">

            
            <div>
                <div class="flex items-start mb-3">
                    <span class="w-32 font-medium">氏名</span>
                    <span><?php echo e($inputs['name']); ?></span>
                </div>
                <div class="border-b border-[#D6D3CE]"></div>
            </div>

            
            <div>
                <div class="flex items-start mb-3">
                    <span class="w-32 font-medium">メールアドレス</span>
                    <span><?php echo e($inputs['email']); ?></span>
                </div>
                <div class="border-b border-[#D6D3CE]"></div>
            </div>

            
            <div>
                <div class="flex items-start mb-3">
                    <span class="w-32 font-medium">件名</span>
                    <span><?php echo e($inputs['subject']); ?></span>
                </div>
                <div class="border-b border-[#D6D3CE]"></div>
            </div>

            
            <div>
                <div class="flex items-start mb-3">
                    <span class="w-32 font-medium">本文</span>
                    <span class="whitespace-pre-line">
                        <?php echo e($inputs['message']); ?>

                    </span>
                </div>
                <div class="border-b border-[#D6D3CE]"></div>
            </div>
        </div>

        
        <form action="<?php echo e(route('contact.complete')); ?>" method="POST" class="text-center">
            <?php echo csrf_field(); ?>

            
            <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key === 'message'): ?>
                    <textarea name="<?php echo e($key); ?>" hidden><?php echo e($value); ?></textarea>
                <?php else: ?>
                    <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button
                type="submit"
                name="action"
                value="back"
                class="py-3 px-10 mr-5 bg-[#F8F8F8] border border-[#363427] text-[#363427] rounded hover:bg-[#e5e5e5] transition">
                戻る
            </button>

            <button
                type="submit"
                class="py-3 px-10 bg-[#363427] text-white rounded hover:opacity-80 transition">
                送信する
            </button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/contact/confirm.blade.php ENDPATH**/ ?>