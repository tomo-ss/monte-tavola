<?php $__env->startSection('title', 'メニュー'); ?>
<?php ($transparent_header = true); ?>

<?php $__env->startSection('title', 'Food Menu'); ?>
<?php $__env->startSection('description', 'Monte Tavola のフードメニュー一覧'); ?>

<?php $__env->startSection('content'); ?>



<section class="relative w-full h-[400px] overflow-hidden">
    <img src="<?php echo e(asset('images/menu/food-hero.jpg')); ?>" 
         class="w-full h-full object-cover brightness-75" 
         alt="Food Menu">

    <div class="absolute inset-0 flex items-center justify-center">
        <h1 class="text-[#F8F8F8] text-4xl md:text-5xl font-serif tracking-wide border border-[#F8F8F8] px-6 py-3"
            style="text-shadow: 0 4px 12px rgba(0,0,0,0.35);">
            Food Menu
        </h1>
    </div>
</section>


<section class="mt-10 mb-12">
    <div class="w-full flex justify-center">
        <div class="inline-flex space-x-10 text-lg font-medium">

            <a href="/menu/food" 
               class="text-[#363427] border-b-2 border-[#363427] pb-1">
                Food
            </a>

            <a href="/menu/drink" 
               class="text-[#6B6861] hover:text-[#363427] pb-1 transition">
                Drink
            </a>

            <a href="/menu/seasonal" 
               class="text-[#6B6861] hover:text-[#363427] pb-1 transition">
                Seasonal
            </a>

        </div>
    </div>
</section>




<section class="py-20 max-w-5xl mx-auto px-6">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-16">

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-1.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">イタリアンサラダ</p>
        </div>

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-2.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">ミネストローネ</p>
        </div>

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-3.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">マルゲリータ</p>
        </div>

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-4.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">ボロネーゼ</p>
        </div>

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-5.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">生ハムとベビーリーフのピッツァ</p>
        </div>

        
        <div class="text-center">
            <img src="<?php echo e(asset('images/menu/food-6.jpg')); ?>" class="w-full shadow-sm mb-3">
            <p class="text-sm tracking-wide text-[#363427]">ティラミス</p>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/menu/food.blade.php ENDPATH**/ ?>