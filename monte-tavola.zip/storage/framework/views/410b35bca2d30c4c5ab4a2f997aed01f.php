<?php ($transparent_header = true); ?>

<?php $__env->startSection('title', 'トップページ'); ?>
<?php $__env->startSection('description', '自然に囲まれた隠れ家レストラン Monte Tavola の公式サイトです。'); ?>
<?php $__env->startSection('body_class', 'top-page'); ?>

<?php $__env->startSection('content'); ?>




<section class="relative w-full overflow-visible z-0">
    <div class="swiper main-visual-swiper h-screen md:h-[850px] overflow-hidden z-0">
        <div class="swiper-wrapper overflow-hidden">
            <?php $__currentLoopData = [1,2,3,4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide overflow-hidden">
                    <img src="<?php echo e(asset("images/top/main-visual-{$i}.jpg")); ?>"
                         class="block w-full h-full object-cover brightness-75 zoom-kenburns">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>






<section id="about"
    class="bg-[#F8F8F8] pt-16 pb-40 px-6 md:px-12 overflow-x-hidden scroll-mt-20">

  <div class="max-w-7xl mx-auto grid md:grid-cols-2 gap-10 items-center">

    
    <div class="flex flex-col items-start">
      <h2 class="text-5xl font-serif text-[#363427] mb-4">About Us</h2>
      <p class="text-[#363427] leading-relaxed max-w-2xl mb-10">私たちについて</p>

      <div class="space-y-4 text-[#363427] leading-relaxed text-[16px]">
        <p>
          長野県の山あいにひっそりと佇む、夫婦で営む小さなイタリアンレストラン。<br>
          澄んだ空気、木々のざわめき、季節のうつろい——そんな自然の豊かさに包まれながら、<br>
          肩ひじ張らずに楽しめるカジュアルなイタリアンをご提供しています。
        </p>
        <p>
          私たちが目指すのは、日常からふっと離れて、心がほどけるようなひととき。<br>
          地元の食材を活かした料理と、温かみのある空間で、<br>
          訪れる方が「また帰ってきたくなる場所」になれたら嬉しいです。
        </p>
        <p>
          自然とともに、静かに、親しみ深く。<br>
          ここでしか味わえない時間を、どうぞごゆっくりお楽しみください。
        </p>
      </div>

      
      <a href="/reservation"
        class="btn-swipe-left-to-right inline-flex w-full md:w-[300px]
               h-[56px] md:h-[64px] px-6 justify-center items-center
               rounded-[10px] border border-[#363427]
               text-[#363427] font-semibold text-lg
               transition relative overflow-hidden mt-6">
        ご予約はこちら
      </a>

    <a href="/contact"
      class="mt-3 block w-full md:w-[300px]
            text-center text-[#363427] underline
            hover:text-green-700 font-medium">
      ご予約以外のお問い合わせはこちらから
    </a>

    </div>

 
<div class="relative w-full flex justify-center mt-6">

 
<div class="w-full max-w-[560px] h-[380px] overflow-hidden shadow-md relative">
<img src="<?php echo e(asset('images/top/about_pasta.jpg')); ?>"
 alt="シーフードパスタ" 
 class="w-full h-full object-cover"> 
</div>

 
<div class="w-[320px] h-[210px] overflow-hidden shadow-md
 absolute bottom-[-180px] left-[-40px]">
  <img src="<?php echo e(asset('images/top/about_staff.jpg')); ?>"
   alt="スタッフの写真" 
   class="w-full h-full object-cover">
  </div>
</div>


    </div>

</section>




<section id="news" class="py-16 px-6 md:px-12 bg-[#F1ECEB]">
  <div class="max-w-7xl mx-auto">

    <h2 class="text-5xl font-serif text-center text-[#363427] mb-2">News</h2>
    <p class="text-center text-[#363427] mb-8">おしらせ</p>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php $__empty_1 = true; $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('news.show', $item->id)); ?>"
           class="bg-white rounded overflow-hidden shadow hover:opacity-90 transition block">

          <div class="overflow-hidden">
            <?php if($item->image_path): ?>
              <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>"
                   class="w-full h-48 object-cover hover:scale-110 transition">
            <?php else: ?>
              <div class="w-full h-48 bg-gray-200"></div>
            <?php endif; ?>
          </div>

          <div class="p-4">
            <h3 class="text-lg text-[#363427] font-semibold mb-2">
              <?php echo e($item->title); ?>

            </h3>
            <p class="text-sm text-gray-500">
              <?php echo e(\Carbon\Carbon::parse($item->published_at)->format('Y.m.d')); ?>

            </p>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-center text-gray-500">お知らせはまだありません。</p>
      <?php endif; ?>
    </div>

    <div class="mt-8 text-center">
      <a href="/news"
         class="inline-block bg-[#363427] text-white px-6 py-3 rounded
                hover:bg-[#4A4844] transition">
        View All
      </a>
    </div>

  </div>
</section>




<section id="menu" class="py-14 px-6">
  <div class="max-w-6xl mx-auto">
    <h2 class="text-5xl font-serif text-center text-[#363427] mb-2">Menu</h2>
    <p class="text-center text-[#363427] mb-6">メニュー</p>

    <div class="flex flex-wrap justify-center gap-6">
      <?php $__currentLoopData = ['food','drink','seasonal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="relative w-[340px]">
  <img
    src="<?php echo e(asset("images/top/menu_{$type}.png")); ?>"
    class="block mx-auto max-w-full h-auto"
  >

  <span
    class="pointer-events-none absolute inset-0 flex items-center justify-center
           font-serif text-white text-3xl md:text-4xl
           font-medium capitalize drop-shadow-lg">
    <?php echo e($type); ?>

  </span>

  <a href="/menu/<?php echo e($type); ?>"
     class="absolute bottom-16 left-1/2 -translate-x-1/2
            px-5 py-2 rounded-[10px]
            bg-[#F8F8F8]/90 text-[#363427]
            hover:bg-[#363427] hover:text-white transition">
    View Menu
  </a>
</div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>





<section id="access" class="py-16 px-6 md:px-12 bg-[#F1ECEB]">
  <div class="max-w-7xl mx-auto text-center">
    <h2 class="text-5xl font-serif text-[#363427] mb-2">Access</h2>
    <p class="text-[#363427] mb-8">アクセス</p>

    <iframe class="w-full h-[350px] border-0"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3214.9969508187446!2d137.636347976502!3d36.24874199533765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601d1c9f3e1c7c0f%3A0x9b2c3c4c9c0a5d5!2z5Lq65aSn5Zyw!5e0!3m2!1sja!2sjp!4v1737180000000"
        loading="lazy"></iframe>

    <p class="text-sm text-gray-500 mt-2">
    ※ 本店舗は架空のため、地図は参考表示です。
    </p>

  

    <div class="mt-8 text-right">
      <a href="/access"
         class="inline-block bg-[#363427] text-white px-6 py-3 rounded
                hover:bg-[#4A4844] transition">
        View Details
      </a>
    </div>
  </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  window.mainSwiper = new Swiper('.main-visual-swiper', {
    loop: true,
    effect: 'fade',
    speed: 1500,
    autoplay: { delay: 3500, disableOnInteraction: false },
    fadeEffect: { crossFade: true },
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta property="og:type" content="website">
<meta property="og:title" content="Monte Tavola｜自然に囲まれた隠れ家イタリアン">
<meta property="og:description" content="自然に囲まれた隠れ家レストラン Monte Tavola。落ち着いた空間で本格イタリアンをお楽しみいただけます。">
<meta property="og:image" content="<?php echo e(asset('images/top/main-visual-1.jpg')); ?>">
<meta property="og:url" content="<?php echo e(url('/')); ?>">
<meta name="twitter:card" content="summary_large_image">
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/top.blade.php ENDPATH**/ ?>