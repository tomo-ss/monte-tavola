<?php $__env->startSection('title', 'おしらせ'); ?>
<?php $__env->startSection('content'); ?>

<div class="max-w-5xl mx-auto py-16">


<div class="max-w-3xl mx-auto mt-20 mb-12 text-center">
    <h1 class="font-serif text-3xl md:text-4xl font-semibold text-[#363427]">
        News
    </h1>
    <p class="mt-2 text-sm text-[#363427]">
        おしらせ
    </p>
</div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">

        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('news.show', $item->id)); ?>"
               class="block shadow bg-white rounded overflow-hidden hover:opacity-90 transition">

                
                <?php if($item->image_path): ?>
                    <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>"
                         class="w-full h-60 object-cover">
                <?php else: ?>
                    <div class="w-full h-60 bg-gray-200"></div>
                <?php endif; ?>

                <div class="p-4">
                    
                    <h2 class="text-lg font-semibold text-[#363427] mb-2">
                        <?php echo e($item->title); ?>

                    </h2>

                    
                    <p class="text-sm text-gray-600">
                        <?php echo e(\Carbon\Carbon::parse($item->published_at)->format('Y.m.d')); ?>

                    </p>
                </div>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    
    <div class="mt-12">
        <?php echo e($news->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/news/index.blade.php ENDPATH**/ ?>