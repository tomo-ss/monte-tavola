<?php $__env->startSection('title', 'ご予約'); ?>
<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex justify-center px-4 pt-32">
    <div class="w-full max-w-3xl">

        
        <h1 class="text-center text-2xl font-semibold text-[#363427] mb-20">
            入力内容ご確認
        </h1>

        
        <div class="max-w-3xl mx-auto bg-[#F1ECEB] rounded-3xl px-10 py-16">

        <p class="text-center text-sm text-[#363427] mb-12 leading-relaxed">
            以下の内容でよろしければ、「送信する」ボタンを押してください。<br>
            内容に誤りがある場合は、「戻る」ボタンで戻ってご確認ください。
        </p>

        
        <div class="mb-12">
            <h2 class="text-sm mb-6">■ ご来店日時</h2>

  <div class="grid grid-cols-[160px_1fr] gap-y-4 text-sm max-w-md mx-auto">
    <div>来店日</div>
    <div><?php echo e(\Carbon\Carbon::parse($data['date'])->format('Y/m/d')); ?></div>

    <div>来店時間</div>
    <div><?php echo e($data['time']); ?></div>

    <div>人数</div>
    <div><?php echo e($data['people_count']); ?>名</div>
</div>


        <hr class="border-[#363427]/30 my-12">

        
        <div class="mb-12">
            <h2 class="text-sm mb-6">■ お客様情報</h2>

            <div class="grid grid-cols-[160px_1fr] gap-y-4 text-sm max-w-md mx-auto">

                <div>氏名</div>
                <div><?php echo e($data['name']); ?></div>

                <div>フリガナ</div>
                <div><?php echo e($data['name_kana']); ?></div>

                <div>電話番号</div>
                <div><?php echo e($data['phone']); ?></div>

                <div>メールアドレス</div>
                <div><?php echo e($data['email']); ?></div>
            </div>
        </div>

        <hr class="border-[#363427]/30 my-12">

        
        <div class="mb-16">
            <h2 class="text-sm mb-6">■ ご要望など</h2>

            <div class="grid grid-cols-[160px_1fr] gap-y-4 text-sm max-w-md mx-auto">
            <div>備考欄</div>
            <div class="whitespace-pre-line">
                <?php echo e($data['note'] ?? '—'); ?>

            </div>
        </div>
        </div>

        
        <form method="POST" action="<?php echo e(route('reservation.store')); ?>"
        class="flex justify-center gap-6">

            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value ?? ''); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <button type="button"
                    onclick="history.back()"
                    class="px-10 h-11 rounded-lg bg-[#363427]/20 text-[#363427] text-sm">
                戻る
            </button>

            <button type="submit"
                    class="px-10 h-11 rounded-lg bg-[#363427] text-white text-sm">
                送信する
            </button>
        </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/reservation/confirm.blade.php ENDPATH**/ ?>