<?php $__env->startSection('title', 'お知らせ管理'); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">

    <h1 class="text-xl font-semibold border-b pb-2 mb-6"
        style="border-color:#5A7193;">
        お知らせ投稿フォーム
    </h1>

    
<?php if($errors->any()): ?>
  <div class="mb-6 rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
    <ul class="list-disc pl-5 space-y-1">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>



    
    <form
        action="<?php echo e(route('admin.news.confirm')); ?>"
        method="POST"
        enctype="multipart/form-data"
        class="bg-white p-10 max-w-6xl mx-auto space-y-5"
    >
        <?php echo csrf_field(); ?>

        
        <div>
            <label class="font-semibold text-[#363427]">■ タイトル</label>
            <input
                type="text"
                name="title"
                class="w-full border border-gray-300 rounded p-2 mt-2"
                value="<?php echo e(old('title')); ?>"
            >
        </div>

        
        <div>
            <label class="font-semibold text-[#363427]">■ 本文</label>
            <textarea
                name="body"
                rows="10"
                class="w-full border border-gray-300 rounded p-2 mt-2"
            ><?php echo e(old('body')); ?></textarea>
        </div>

        
        <div>
            <label class="font-semibold text-[#363427]">■ ファイルアップロード</label>
            <input
                type="file"
                name="image"
                class="border border-gray-300 rounded p-2 w-full mt-2"
            >
        </div>

        
        <div>
            <label class="font-semibold text-[#363427]">■ 公開日</label>
            <input
                type="date"
                name="published_at"
                class="border border-gray-300 rounded p-2 w-60 mt-2"
                value="<?php echo e(old('published_at')); ?>"
            >
        </div>

        
        <div class="flex justify-center mt-16">
            <button
                type="submit"
                class="bg-[#2C406E] text-white px-10 py-2 rounded hover:opacity-90 transition"
            >
                確認画面へ
            </button>
        </div>

    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/admin/news/create.blade.php ENDPATH**/ ?>