<?php $__env->startSection('title', 'お問い合わせ'); ?>
<?php $__env->startSection('content'); ?>
<div class="py-16">
    
    
    <div class="max-w-3xl mx-auto mt-20 mb-6 text-center">
    <h1 class="font-serif text-3xl md:text-4xl font-semibold text-[#363427]">
        Contact
    </h1>
    <p class="mt-2 text-sm text-[#363427]">
        お問い合わせ
    </p>
    </div>


    
    <div class="max-w-3xl mx-auto bg-[#F1ECEB] p-10 rounded-2xl shadow-sm">

        
        <div class="text-center text-sm text-[#363427] leading-relaxed mb-10">
            <p>ご予約以外のお問い合わせについてはこちらからお願いいたします。</p>
            <p>アレルギーや食材の確認、取材・ご協力の依頼などもこちらからお気軽にどうぞ。</p>
            <p class="mt-4">
                ※内容によっては返信にお時間をいただく場合がございます。<br>
                ※営業中・営業時間外のお問い合わせは、営業日以降にご返信いたします。
            </p>
        </div>

    
    <?php if($errors->any()): ?>
    <div class="max-w-3xl mx-auto mb-8 rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
        <ul class="list-disc pl-5 space-y-1">
        <?php
            $order = [
            'name',
            'email',
            'subject',
            'message',
            ];
        ?>

        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <li><?php echo e($message); ?></li>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>


        
        <form action="<?php echo e(route('contact.confirm')); ?>" method="POST" class="space-y-6" novalidate>
            <?php echo csrf_field(); ?>

            
            <div>
                <label class="block font-medium text-[#363427] mb-2">
                    氏名
                    <span class="ml-2 bg-[#363427] text-white text-xs px-2 py-1 rounded">必須</span>
                </label>
                <input type="text" 
                    name="name"
                    value="<?php echo e(old('name')); ?>"
                    class="w-full border border-[#D6D3CE] p-3 rounded bg-[#F8F8F8] focus:ring-2 focus:ring-[#363427]"
                    placeholder="例）山中 三郎">
            </div>

            
            <div>
                <label class="block font-medium text-[#363427] mb-2">
                    メールアドレス
                    <span class="ml-2 bg-[#363427] text-white text-xs px-2 py-1 rounded">必須</span>
                </label>
                <input type="email" 
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    class="w-full border border-[#D6D3CE] p-3 rounded bg-[#F8F8F8] focus:ring-2 focus:ring-[#363427]"
                    placeholder="例）yamanaka@example.com">
            </div>

            
            <div>
                <label class="block font-medium text-[#363427] mb-2">
                    件名
                    <span class="ml-2 bg-[#363427] text-white text-xs px-2 py-1 rounded">必須</span>
                </label>
                <input type="text" 
                        name="subject"
                        value="<?php echo e(old('subject')); ?>"
                        placeholder="例）アレルギーについてのご相談"
                        class="w-full border border-[#D6D3CE] p-3 rounded bg-[#F8F8F8] focus:ring-2 focus:ring-[#363427]">
                 </div>

            
            <div>
                <label class="block font-medium text-[#363427] mb-2">
                    本文
                    <span class="ml-2 bg-[#363427] text-white text-xs px-2 py-1 rounded">必須</span>
                </label>
                <textarea 
                    name="message" 
                    rows="10"
                    placeholder="例）卵が含まれているメニューを教えてください。"
                    class="w-full border border-[#D6D3CE] p-3 rounded bg-[#F8F8F8] focus:ring-2 focus:ring-[#363427]"><?php echo e(old('message')); ?></textarea>

            </div>

            
            <div class="text-center mt-10">
                <button type="submit"
                    class="bg-[#363427] text-white py-3 px-10 rounded hover:opacity-80 transition">
                    確認画面へ
                </button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/contact/form.blade.php ENDPATH**/ ?>