<?php $__env->startSection('title', 'お問い合わせ'); ?>
<?php $__env->startSection('content'); ?>
<div class="pt-52 pb-60">

    
    <h1 class="text-center text-2xl font-semibold text-[#363427] tracking-wide mb-48">
        お問い合わせ完了
    </h1>

    
    <div class="text-center mb-52">  
        <p class="text-[#363427] text-2xl font-medium mb-6">
            お問い合わせを受け付けました。
        </p>
        <p class="text-[#363427] text-base leading-relaxed">
            内容確認のうえ、担当者よりご連絡いたします。
        </p>
    </div>

    
    <div class="text-center">
        <a href="<?php echo e(url('/')); ?>"
           class="py-3 px-14 bg-[#363427] text-white rounded hover:opacity-80 transition text-sm tracking-wide">
            TOPへ戻る
        </a>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monte-tavola/resources/views/contact/complete.blade.php ENDPATH**/ ?>