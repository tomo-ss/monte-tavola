<!DOCTYPE html>
<html lang="ja" dir="ltr" class="overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> | Monte Tavola</title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldPushContent('meta'); ?>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


</head>

<body id="app"
      class="<?php echo $__env->yieldContent('body_class'); ?>
             bg-[#F8F8F8] text-gray-800 font-sans
             overflow-x-hidden">



    
    <?php echo $__env->make('partials.header', [
        'transparent_header' => !empty($transparent_header)
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="min-h-screen">
    <?php echo $__env->yieldContent('content'); ?>
</main>




    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.mobile-menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>


    
    <div id="overlay-root"></div>

</body>
</html>
<?php /**PATH /workspaces/monte-tavola/resources/views/layouts/app.blade.php ENDPATH**/ ?>